// LoginScreen: sign-in form for existing users — validates, calls signIn, and
// surfaces API errors inline; links over to the signup flow.

// Imports: layout/keyboard primitives, icon + status bar, and shared auth UI.
import React, { useState } from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  Text,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import { getErrorMessage } from '@/services/api';
import { colors } from '@/theme';
import { useAuth } from '@/context/AuthContext';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { ErrorBanner } from '@/components/ui/ErrorBanner';

// onShowSignup tells the shell to flip to the account-creation screen.
type LoginScreenProps = {
  onShowSignup: () => void;
};

export function LoginScreen({ onShowSignup }: LoginScreenProps) {
  // signIn mutation plus email/password state, visibility toggle, and local error/loading flags.
  const { signIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Normalizes the email, validates both fields, then signs in.
  const handleLogin = async () => {
    const normalizedEmail = email.trim().toLowerCase();
    if (!normalizedEmail || !password) {
      setError('Enter your email and password.');
      return;
    }

    setLoading(true);
    setError('');
    try {
      await signIn({ email: normalizedEmail, password });
    } catch (nextError) {
      setError(getErrorMessage(nextError, 'Could not sign in.'));
    } finally {
      setLoading(false);
    }
  };

  return (
    // Keyboard-aware and scrollable so the form never hides under the keyboard.
    <SafeAreaView className="flex-1 bg-background">
      <KeyboardAvoidingView
        className="flex-1 bg-background"
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerClassName="flex-grow justify-center px-[22px] py-[32px]"
          keyboardShouldPersistTaps="handled"
        >
          <View className="flex-row items-center gap-[10px] mb-[44px]">
            {/* Brand mark and app name. */}
            <View className="w-[44px] h-[44px] rounded-[15px] bg-leaf items-center justify-center" accessibilityElementsHidden>
              <Ionicons name="leaf" size={24} color={colors.surface} />
            </View>
            <Text className="text-ink text-[22px] font-extrabold tracking-tight">Chokro</Text>
          </View>

          {/* Welcome copy teasing the app's value proposition. */}
          <View className="mb-[24px]">
            <Text className="text-leaf text-[12px] leading-[18px] font-extrabold tracking-[1.4px]">CIRCULAR, WITH PROOF</Text>
            <Text accessibilityRole="header" className="text-ink text-[36px] leading-[42px] font-extrabold tracking-tight mt-[5px]">Welcome back</Text>
            <Text className="text-muted text-[16px] leading-[24px] mt-[9px] max-w-[420px]">Sign in to list useful items, recognize drop zones, and see verified Green Credits.</Text>
          </View>

          {/* The login card: email/password, inline error, submit, and signup link. */}
          <View className="bg-surface rounded-lg border border-border p-[20px] shadow-card" style={{ elevation: 2 }}>
            <Input
              label="Email address"
              accessibilityLabel="Email address"
              placeholder="you@example.com"
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
              autoCorrect={false}
              keyboardType="email-address"
              textContentType="emailAddress"
              editable={!loading}
            />

            <Input
              label="Password"
              accessibilityLabel="Password"
              placeholder="Your password"
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
              textContentType="password"
              editable={!loading}
              onSubmitEditing={() => void handleLogin()}
              rightAccessory={
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel={showPassword ? 'Hide password' : 'Show password'}
                  className="p-[6px] -mr-[4px] justify-center items-center active:opacity-60"
                  hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                  onPress={() => setShowPassword((prev) => !prev)}
                >
                  <Ionicons
                    name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                    size={22}
                    color={colors.muted}
                  />
                </Pressable>
              }
            />

            {/* Surfaces a failed-sign-in message, if any. */}
            {error ? <ErrorBanner message={error} /> : null}

            <Button
              label="Sign in"
              loading={loading}
              onPress={() => void handleLogin()}
            />

            {/* Flipping to signup — hidden while a sign-in request is pending. */}
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Create a new account"
              className="min-h-[48px] items-center justify-center px-[4px] mt-[8px] active:opacity-[0.75]"
              onPress={onShowSignup}
              disabled={loading}
            >
              <Text className="text-muted text-[14px]">New to Chokro? <Text className="text-leaf-dark font-extrabold">Create an account</Text></Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
      <StatusBar style="dark" />
    </SafeAreaView>
  );
}
