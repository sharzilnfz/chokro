// CreateListingScreen is the "List" tab form: it captures a photo, category,
// quantity, and declared condition, shows a live BDT estimate, and publishes
// the item as an active listing.

// Imports: core React/hooks, UI primitives, icons, and internal data modules.
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getErrorMessage } from '@/services/api';
import { colors } from '@/theme';
import { CATEGORIES, CONDITIONS, categoryLabel, formatQuantityWithUnit, getCategoryUnit, type Category, type Condition } from '@/types';
import { PhotoUploader } from '@/components/PhotoUploader';
import { EstimatorCard } from '@/components/EstimatorCard';
import { useCreateListing } from '@/hooks/useCreateListing';
import { useEstimate } from '@/hooks/useEstimate';
import { pickAndCompressPhoto, takeAndCompressPhoto, type PreparedPhoto } from '@/lib/photo';
import type { ListingPrefill } from '@/types';
import { isPieceCategory } from '@chokro/shared';

// onCreated fires after a successful publish so the shell returns to Browse.
type CreateListingScreenProps = {
  onCreated: () => void;
  prefill?: ListingPrefill | null;
};

export function CreateListingScreen({ onCreated, prefill = null }: CreateListingScreenProps) {
  const [category, setCategory] = useState<Category>(prefill?.category ?? 'PLASTICS');
  const [condition, setCondition] = useState<Condition>(prefill?.condition ?? 'GOOD');
  const [quantity, setQuantity] = useState(prefill && prefill.quantity > 0 ? String(prefill.quantity) : '');
  const [price, setPrice] = useState('');
  const [photo, setPhoto] = useState<PreparedPhoto | null>(prefill?.photo ?? null);
  const [preparingPhoto, setPreparingPhoto] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState(
    prefill ? 'Prefilled from your AI scan — adjust anything before publishing.' : '',
  );
  const createListing = useCreateListing();
  const { data: estimate, isLoading: estimateLoading } = useEstimate(category, condition);
  // Fires the onCreated navigation once after a successful publish.
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Clear the pending publish-navigation timer when the screen unmounts.
  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  // Derived values: per-category unit, parsed/validated quantity, and BDT total.
  const unit = getCategoryUnit(category);
  const maxPhotos = isPieceCategory(category) ? 5 : 3;
  const parsedQuantity = parseFloat(quantity);
  const hasValidQuantity = Number.isFinite(parsedQuantity) && parsedQuantity > 0;
  const parsedPrice = parseFloat(price);
  const hasValidPrice = Number.isFinite(parsedPrice) && parsedPrice > 0;
  const ratePerUnit = estimate ? Number(estimate.price_bdt) : 0;
  const totalEstimatedBdt = (hasValidQuantity && estimate && Number.isFinite(ratePerUnit))
    ? parsedQuantity * ratePerUnit
    : null;

  // Changing category also clears the old quantity since the unit label changes.
  const selectCategory = useCallback((nextCategory: Category) => {
    setCategory(nextCategory);
    setQuantity('');
    setError('');
  }, []);

  // Picks and compresses a photo from gallery
  const pickPhoto = useCallback(async () => {
    setPreparingPhoto(true);
    setError('');
    setNotice('');
    try {
      const nextPhoto = await pickAndCompressPhoto();
      if (!nextPhoto) return;
      setPhoto(nextPhoto);
      setNotice(`Photo ready: ${nextPhoto.width} x ${nextPhoto.height}, ${Math.ceil(nextPhoto.bytes / 1024)} KB.`);
    } catch (nextError) {
      setError(getErrorMessage(nextError, 'Could not prepare this photo.'));
    } finally {
      setPreparingPhoto(false);
    }
  }, []);

  // Takes and compresses a photo using camera
  const takePhoto = useCallback(async () => {
    setPreparingPhoto(true);
    setError('');
    setNotice('');
    try {
      const nextPhoto = await takeAndCompressPhoto();
      if (!nextPhoto) return;
      setPhoto(nextPhoto);
      setNotice(`Photo captured: ${nextPhoto.width} x ${nextPhoto.height}, ${Math.ceil(nextPhoto.bytes / 1024)} KB.`);
    } catch (nextError) {
      setError(getErrorMessage(nextError, 'Could not capture photo.'));
    } finally {
      setPreparingPhoto(false);
    }
  }, []);

  // Validates photo + quantity, then publishes and schedules navigation away.
  const handleSubmit = useCallback(async () => {
    if (!photo) {
      setError('Add a real item photo before publishing.');
      return;
    }
    if (!hasValidQuantity) {
      setError(unit === 'kg' ? 'Enter a weight greater than 0 kg.' : 'Enter at least 1 piece.');
      return;
    }
    if (unit === 'piece' && !Number.isInteger(parsedQuantity)) {
      setError('Piece count must be a whole number.');
      return;
    }
    const effectivePrice = hasValidPrice
      ? parsedPrice
      : (totalEstimatedBdt !== null ? totalEstimatedBdt : (ratePerUnit > 0 ? ratePerUnit * parsedQuantity : null));

    if (!effectivePrice || effectivePrice <= 0) {
      setError('Enter an asking price greater than 0.');
      return;
    }

    setError('');
    setNotice('');
    try {
      await createListing.mutateAsync({
        category,
        unit,
        ...(unit === 'kg'
          ? { declaredWeight: parsedQuantity }
          : { pieceCount: parsedQuantity }),
        declaredCondition: condition,
        price: effectivePrice,
        photos: [photo.dataUri],
      });
      setNotice('Listing published as active. It is now available in Browse.');
      timerRef.current = setTimeout(onCreated, 650);
    } catch (nextError) {
      setError(getErrorMessage(nextError, 'Could not publish this listing.'));
    }
  }, [category, condition, createListing, hasValidPrice, hasValidQuantity, onCreated, parsedPrice, parsedQuantity, photo, ratePerUnit, totalEstimatedBdt, unit]);

  // Scrollable, keyboard-aware form; each field group is a numbered step card.
  return (
    <ScrollView
      className="flex-1 bg-background"
      contentContainerClassName="p-[20px] pb-[36px]"
      keyboardShouldPersistTaps="handled"
    >
      {/* Header copy: partners confirm exact condition/value later. */}
      <Text className="text-leaf text-[11px] font-extrabold tracking-[1.3px]">GIVE IT A NEXT LIFE</Text>
      <Text accessibilityRole="header" className="text-ink text-[31px] leading-[37px] font-extrabold tracking-tight mt-[4px]">List an item</Text>
      <Text className="text-muted text-[14px] leading-[21px] mt-[7px] mb-[22px]">Choose only what you know. Final condition and value are confirmed by a partner later.</Text>

      {/* Photo step: compound PhotoUploader with camera and gallery actions. */}
      <PhotoUploader
        photo={photo}
        preparingPhoto={preparingPhoto}
        maxPhotos={maxPhotos}
        onPickPhoto={() => void pickPhoto()}
        onTakePhoto={() => void takePhoto()}
        onRemovePhoto={() => {
          setPhoto(null);
          setNotice('');
        }}
      />


      <View className="bg-surface border border-border rounded-md p-[16px] mb-[13px] shadow-card" style={{ elevation: 2 }}>
        {/* Step 02 — category selection as radio-style chips. */}
        <View className="flex-row items-center gap-[9px] mb-[13px]">
          <Text className="text-leaf text-[11px] font-black tracking-[0.8px]">02</Text>
          <Text className="text-ink text-[17px] font-extrabold">Category</Text>
        </View>
        <View className="flex-row flex-wrap gap-[8px]">
          {CATEGORIES.map((item) => {
            const selected = category === item;
            return (
              <Pressable
                key={item}
                accessibilityRole="radio"
                accessibilityLabel={categoryLabel(item)}
                accessibilityState={{ checked: selected }}
                className={`min-h-[48px] px-[13px] rounded-pill border items-center justify-center active:opacity-[0.72] ${selected ? 'bg-leaf-soft border-leaf' : 'bg-background border-border'}`}
                onPress={() => selectCategory(item)}
              >
                <Text className={`text-[13px] font-bold ${selected ? 'text-leaf-dark' : 'text-muted'}`}>{categoryLabel(item)}</Text>
              </Pressable>
            );
          })}
        </View>
      </View>

      <View className="bg-surface border border-border rounded-md p-[16px] mb-[13px] shadow-card" style={{ elevation: 2 }}>
        {/* Step 03 — weight (kg) or piece-count input depending on the category. */}
        <View className="flex-row items-center gap-[9px] mb-[13px]">
          <Text className="text-leaf text-[11px] font-black tracking-[0.8px]">03</Text>
          <Text className="text-ink text-[17px] font-extrabold">{unit === 'kg' ? 'Weight' : 'Quantity'}</Text>
        </View>
        <View className="flex-row">
          <TextInput
            accessibilityLabel={unit === 'kg' ? 'Estimated weight in kilograms' : 'Number of pieces'}
            className="flex-1 min-h-[52px] border border-r-0 border-border rounded-tl-[12px] rounded-bl-[12px] bg-background text-ink text-[17px] px-[14px]"
            placeholder={unit === 'kg' ? 'e.g. 2.5' : 'e.g. 1'}
            placeholderTextColor={colors.muted}
            keyboardType={unit === 'kg' ? 'decimal-pad' : 'number-pad'}
            value={quantity}
            onChangeText={setQuantity}
          />
          <View className="min-w-[88px] min-h-[52px] border border-border rounded-tr-[12px] rounded-br-[12px] bg-surface-muted items-center justify-center px-[12px]">
            <Text className="text-ink text-[14px] font-extrabold">{unit === 'kg' ? 'kg' : 'pieces'}</Text>
          </View>
        </View>
        <Text className="text-muted text-[12px] leading-[18px] mt-[7px]">{unit === 'kg' ? 'Materials are listed by estimated kilograms.' : 'Appliances and e-waste are listed by whole pieces.'}</Text>
      </View>

      <View className="bg-surface border border-border rounded-md p-[16px] mb-[13px] shadow-card" style={{ elevation: 2 }}>
        {/* Step 04 — declared condition chips plus the publish-status row. */}
        <View className="flex-row items-center gap-[9px] mb-[13px]">
          <Text className="text-leaf text-[11px] font-black tracking-[0.8px]">04</Text>
          <Text className="text-ink text-[17px] font-extrabold">Declared condition</Text>
        </View>
        <View className="flex-row flex-wrap gap-[8px]">
          {CONDITIONS.map((item) => {
            const selected = condition === item;
            return (
              <Pressable
                key={item}
                accessibilityRole="radio"
                accessibilityLabel={`Condition ${categoryLabel(item)}`}
                accessibilityState={{ checked: selected }}
                className={`min-h-[48px] px-[13px] rounded-pill border items-center justify-center active:opacity-[0.72] ${selected ? 'bg-leaf-soft border-leaf' : 'bg-background border-border'}`}
                onPress={() => setCondition(item)}
              >
                <Text className={`text-[13px] font-bold ${selected ? 'text-leaf-dark' : 'text-muted'}`}>{categoryLabel(item)}</Text>
              </Pressable>
            );
          })}
        </View>
        {/* Listings go live as Active; shown as a static status indicator. */}
        <View className="min-h-[48px] flex-row items-center gap-[8px] border-t border-border mt-[14px] pt-[12px]">
          <Ionicons name="radio-button-on" size={17} color={colors.leaf} />
          <Text className="text-muted text-[13px] font-bold">Publishing status: Active</Text>
        </View>
      </View>

      <View className="bg-surface border border-border rounded-md p-[16px] mb-[13px] shadow-card" style={{ elevation: 2 }}>
        <View className="flex-row items-center gap-[9px] mb-[13px]">
          <Text className="text-leaf text-[11px] font-black tracking-[0.8px]">05</Text>
          <Text className="text-ink text-[17px] font-extrabold">Asking price (optional)</Text>
        </View>
        <View className="flex-row">
          <View className="min-w-[70px] min-h-[52px] border border-r-0 border-border rounded-tl-[12px] rounded-bl-[12px] bg-surface-muted items-center justify-center px-[12px]">
            <Text className="text-ink text-[16px] font-extrabold">৳</Text>
          </View>
          <TextInput
            accessibilityLabel="Asking price in Bangladeshi Taka"
            className="flex-1 min-h-[52px] border border-border rounded-tr-[12px] rounded-br-[12px] bg-background text-ink text-[17px] px-[14px]"
            placeholder={totalEstimatedBdt !== null ? `Est. ৳${totalEstimatedBdt.toFixed(2)}` : 'e.g. 50'}
            placeholderTextColor={colors.muted}
            keyboardType="decimal-pad"
            value={price}
            onChangeText={setPrice}
          />
        </View>
        <Text className="text-muted text-[12px] leading-[18px] mt-[7px]">Leave blank to use the official benchmarked rate estimate.</Text>
      </View>

      <EstimatorCard
        className="mb-[13px]"
        estimate={estimate ?? null}
        isLoading={estimateLoading}
        notFound={!estimateLoading && !estimate}
        hasQuantity={hasValidQuantity}
        quantityLabel={formatQuantityWithUnit(unit, hasValidQuantity ? parsedQuantity : undefined)}
        category={category}
        condition={condition}
        totalBdt={totalEstimatedBdt}
      />

      {/* Inline error or success notice for validation and publish outcomes. */}
      {error ? <Text accessibilityRole="alert" className="text-danger bg-danger-soft p-[13px] rounded-[12px] text-[14px] leading-[20px] font-semibold mb-[12px]">{error}</Text> : null}
      {notice ? <Text accessibilityRole="alert" className="text-leaf-dark bg-leaf-soft p-[13px] rounded-[12px] text-[14px] leading-[20px] font-semibold mb-[12px]">{notice}</Text> : null}

      {/* Submit button, disabled while a photo is preparing or the publish is pending. */}
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Publish active listing"
        accessibilityState={{ disabled: createListing.isPending || preparingPhoto, busy: createListing.isPending }}
        className={`min-h-[54px] rounded-[15px] bg-leaf items-center justify-center mt-[3px] active:opacity-[0.72] ${(createListing.isPending || preparingPhoto) ? 'opacity-[0.55]' : ''}`}
        disabled={createListing.isPending || preparingPhoto}
        onPress={() => void handleSubmit()}
      >
        {createListing.isPending ? <ActivityIndicator color={colors.surface} /> : <Text className="text-surface text-[16px] font-extrabold">Publish listing</Text>}
      </Pressable>
    </ScrollView>
  );
}
